package ser.hzcastblog;

import java.io.Serializable;

/**
 * from hzcast blog
 */
public class OrderLine implements Serializable {
    public String product;
    public int amount;
}