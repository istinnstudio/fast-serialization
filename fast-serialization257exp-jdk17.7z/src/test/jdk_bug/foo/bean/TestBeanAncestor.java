package jdk_bug.foo.bean;

import java.io.Serializable;


public class TestBeanAncestor implements Serializable {

	public UtilFactory factory = new UtilFactory();
}
