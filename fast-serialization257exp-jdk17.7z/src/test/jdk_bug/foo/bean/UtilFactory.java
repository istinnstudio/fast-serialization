package jdk_bug.foo.bean;

import java.io.Serializable;


public class UtilFactory extends UtilFactoryAncestor implements Serializable {
	
	
}
