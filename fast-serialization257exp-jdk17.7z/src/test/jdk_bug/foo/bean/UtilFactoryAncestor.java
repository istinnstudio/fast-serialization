package jdk_bug.foo.bean;


public class UtilFactoryAncestor {
	
	public SomeAbstract a = new AnImpl();
}
