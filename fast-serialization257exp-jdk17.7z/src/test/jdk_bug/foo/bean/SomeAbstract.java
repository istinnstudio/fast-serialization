package jdk_bug.foo.bean;


public abstract class SomeAbstract {

}
